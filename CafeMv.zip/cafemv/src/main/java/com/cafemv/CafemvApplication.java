package com.cafemv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafemvApplication {

	public static void main(String[] args) {
		SpringApplication.run(CafemvApplication.class, args);
	}

}
