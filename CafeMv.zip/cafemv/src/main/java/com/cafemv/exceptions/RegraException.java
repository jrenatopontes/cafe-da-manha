package com.cafemv.exceptions;

public class RegraException extends RuntimeException{
	
	public RegraException(String msg) {
		super(msg);
	}

}
